<?php
    require('includes/conexao.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Contatos</title>
</head>
<body>
    <table border="1">
        <tr>
            <td>id</td>
            <td>Nome</td>
            <td>Email</td>
            <td>cpf</td>
            <td>telefone</td>
        </tr>

        <?php
            $sql = "SELECT * FROM registro-de-clientes";
            $result = mysqli_query($conn, $sql);
            While($registro = mysqli_fetch_assoc($result)){
                $id = $registro['id'];
                $nome = $registro['nome'];
                $email = $registro['email'];
                $sobrenome = $registro['sobrenome'];
                $mensagem  = $registro['mensagem'];
                echo "
                    <tr>
                        <td>$id</td>
                        <td>$nome</td>
                        <td>$sobrenome</td>
                        <td>$email</td>
                        <td>$mensagem</td> 
                        <td></td>
                    </tr>
                ";
            }
        ?>
    </table>
</body>
</html>