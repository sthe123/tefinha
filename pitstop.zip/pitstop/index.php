<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Pit Stop Auto-peças</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Bocor - v4.7.1
  * Template URL: https://bootstrapmade.com/bocor-bootstrap-template-nice-animation/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <h1><a href="index.html">PIT STOP AUTO-PEÇAS<span>.</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Inicio</a></li>
        
          <li><a class="nav-link scrollto" href="services.html">Serviços</a></li>
          <li><a class="nav-link scrollto" href="#portfolio">Produtos</a></li>
         
            <ul>
              
          </li>
          <li><a class="nav-link scrollto" href="#contact">Contato</a></li>
          
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">

    <div class="container">
      <div class="row d-flex align-items-center"">
      <div class=" col-lg-6 py-5 py-lg-0 order-2 order-lg-1" data-aos="fade-right">
        <h1>Peças Automotivas</h1>
        <h2>Melhores peças para seu carro</h2>
        <a href="produtos.html" class="btn-get-started scrollto">iniciar compras</a>
      </div>
      <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left">
        <img src="assets/img/logosite.jpeg" class="img-fluid" alt="">
      </div>
    </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients section-bg">
      <div class="container">

        <div class="row no-gutters clients-wrap clearfix wow fadeInUp">

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/chevrolet.png" class="img-fluid" alt="" data-aos="flip-right">
            </div>
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/toyota-img.png" class="img-fluid" alt="" data-aos="flip-right" data-aos-delay="100">
            </div>
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/citron.png" class="img-fluid" alt="" data-aos="flip-right" data-aos-delay="200">
            </div>
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/Jeep-img.png" class="img-fluid" alt="" data-aos="flip-right" data-aos-delay="300">
            </div>
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/fiat-img.png" class="img-fluid" alt="" data-aos="flip-right" data-aos-delay="400">
            </div>
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/volks-img.png" class="img-fluid" alt="" data-aos="flip-right" data-aos-delay="500">
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Clients Section -->

    <!-- ======= About Section ======= -->
   <!-- End About Section -->

    <!-- ======= Services Section ======= -->
    <!-- End Services Section -->

    <!-- ======= Features Section ======= -->
    <!-- End Features Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio section-bg">
      <div class="container">

        <div class="section-title">
          <h2 data-aos="fade-in">Peças e acessórios automobilísticos</h2>
          <p data-aos="fade-in">Verífique a disponibilidade de peças e acessórios para o seu seu automovel, de acordo com a sua necessidade e o seu gosto. </p>
        
        <br>
          <p data-aos="fade-in"> <strong>PEÇAS</strong></p>
       <br>
        </div>

        <div class="row">
          <div class="col-lg-12">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">TODOS</li>
              <li data-filter=".filter-app">PEÇAS PESADAS</li>
              <li data-filter=".filter-card">ACESSÓRIOS</li>
                 
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/kittoyota-1.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/kittoyota-1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Peças do motor para toyota 2gr-fe, cabeça do cilindro, kit de junta"><i class="bi bi-plus"></i></a>
                <a href="Portfolio/portfolio-1.html" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Peças do motor para toyota 2gr-fe, cabeça do cilindro, kit de junta</h4>
                <p>kit</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/kittoyota-2.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/kittoyota-2.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Kit Embreagem Toyota Bandeirantes 3.7 99 Luk"><i class="bi bi-plus"></i></a>
                <a href="Portfolio/portfolio-2.html" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Kit Embreagem Toyota Bandeirantes 3.7 99 Luk</h4>
                <p>kit</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/motorcitron.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/motorcitron.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Motor DV6FCU Citroen Jumpy Peugeot Expert 1.6 HDI 115cv"><i class="bi bi-plus"></i></a>
                <a href="portfolio/portfolio-3.html" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Motor DV6FCU Citroen Jumpy Peugeot Expert 1.6 HDI 115cv</h4>
                <p>kit</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/capabanco.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/capabanco.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Capa banco de Carro Couro FIAT PALIO 2015 - EXCELÊNCIA-CAR"><i class="bi bi-plus"></i></a>
                <a href="portfolio/portfolio-4.html" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Capa banco de Carro Couro FIAT PALIO 2015 - EXCELÊNCIA-CAR</h4>
                <p>kit</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/pneu.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/pneu.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Pneu van citroen jumper"><i class="bi bi-plus"></i></a>
                <a href="portfolio/portfolio-5.html" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Pneu van citroen jumper</h4>
                <p>kit</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/pistao.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/pistao.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Pistão C/ Biela Jeep Renegade 1.8 Flex 2019 2020"><i class="bi bi-plus"></i></a>
                <a href="portfolio/portfolio-6.html" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Pistão C/ Biela Jeep Renegade 1.8 Flex 2019 2020</h4>
                <p>kit</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/led.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/led.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="KIT LÂMPADAS SUPER LED COOLER 6000K CARRO H1 H7 H8 H9 H11"><i class="bi bi-plus"></i></a>
                <a href="portfolio/portfolio-7.html" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>KIT LÂMPADAS SUPER LED COOLER 6000K CARRO H1 H7 H8 H9 H11</h4>
                <p>Kit</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/bagagem.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/bagagem.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="BAGAGEIRO MALEIRO DE TETO 510 LITROS 50KG PRETO UNIVERSAL"><i class="bi bi-plus"></i></a>
                <a href="portfolio/portfolio-8.html" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>BAGAGEIRO MALEIRO DE TETO 510 LITROS 50KG PRETO UNIVERSAL</h4>
                <p>kit</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/vela.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/vela.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Kit Vela Ignição Toyota Corolla 1.6 16V 97-99 Gasolina Bosch"><i class="bi bi-plus"></i></a>
                <a href="portfolio/portfolio-9.html" title="More Details"><i class="bi bi-link"></i></a>
              </div>
              <div class="portfolio-info">
                <h4>Kit Vela Ignição Toyota Corolla 1.6 16V 97-99 Gasolina Bosch</h4>
                <p>Web</p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Team Section ======= -->
     <section id="team" class="team section-bg">
      <div class="container">

        <div class="section-title">
          <h2 data-aos="fade-in">Promoções</h2>
          <p data-aos="fade-in"></p>
        </div>

        <div class="row">
          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="member" data-aos="fade-up">
              <div class="pic"><img src="assets/img/team/50_.jpeg" alt=""></div>
              <h4>desconto para novos clientes</h4>
              <span>novos clientes que fizeram cadastro recentemente ganha 50% de desconto.</span>
              
            </div>
          </div>


          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="member" data-aos="fade-up" data-aos-delay="200">
              <div class="pic"><img src="assets/img/team/15_.jpeg" alt=""></div>
              <h4>descontos unicos</h4>
              <span>15% de descontos para compra a cima de R$500,00</span>
             
            </div>
          </div>

        </div>

      </div>
    </section>
   <!-- End Team Section -->

    <!-- ======= Pricing Section ======= -->
<!-- End Pricing Section -->

    <!-- ======= Frequently Asked Questions Section ======= -->
   <!-- End Frequently Asked Questions Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Fale Conosco</h2>
          <p>Caso de duvidas ou problemas nos contate para nós resolver o mais rapido possivel</p>
        </div>

        <div class="row">

          <div class="col-lg-6">

            <div class="row">
              <div class="col-md-12">
                <div class="info-box" data-aos="fade-up">
                  <i class="bx bx-map"></i>
                  <h3>Mombaça</h3>
                  <p>Rua Pedro Jaime, MOMBAÇA, CE  63610000</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4" data-aos="fade-up" data-aos-delay="100">
                  <i class="bx bx-envelope"></i>
                  <h3>Nosso Email</h3>
                  <p>attivaweb.software@gmail.com</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4" data-aos="fade-up" data-aos-delay="100">
                  <i class="bx bx-phone-call"></i>
                  <h3>Número</h3>
                  <p>+55 88 8171-0481</p>
                </div>
              </div>
            </div>

          </div>

          <div class="col-lg-6 mt-4 mt-lg-0">
            <form action="acoes/salvar-contato.php" method="post" role="form" class="php-email-form w-100" data-aos="fade-up">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="nome" class="form-control" id="name" placeholder="Nome" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="sobrenome" id="subject" placeholder="Sobrenome" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="mensagem" rows="5" placeholder="Mensagem" required></textarea>
              </div>
              <div class="my-3">
    
                <div class="sent-message">Mensagem enviada com sucesso</div>
              </div>
              <div class="text-center"><button type="submit">Enviar sua Mensagem</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">

      <div class="container">

        <div class="row  justify-content-center">
          <div class="col-lg-6">
            <h3>PIT STOP AUTO-PEÇAS</h3>
            <p>CASO ESTEJA COM PROBLEMA AO ACESSAR OS PRODUTOS OU ALGO DO TIPO, COMUNIQUE-SE CONOSCO COLOCANDO SEU EMAIL ABAIXO.</p>
          </div>
        </div>

        <div class="row footer-newsletter justify-content-center">
          <div class="col-lg-6">
            <form action="" method="post">
              <input type="email" name="email" placeholder="Entre com seu Email"><input type="submit" value="Enviar">
            </form>
          </div>
        </div>

        <div class="social-links">
         
          <a href="https://m.facebook.com/home.php?ref=wizard&_rdr" class="facebook" target="_blank"><i class="bx bxl-facebook"></i></a>
          <a href="https://www.instagram.com/attiva.web/" class="instagram" target="_blank"><i class="bx bxl-instagram"></i></a>
         
        </div>

      </div>
    </div>

    <div class="container footer-bottom clearfix">
      <div class="copyright">
        &copy; Copyright <strong><span>Attiva Web</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bocor-bootstrap-template-nice-animation/ -->
        Designed by <a href="#">Attiva Web</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>