<?php 

$conn = mysqli_connect('localhost', 'root', '');

if($conn){
    mysqli_select_db( $conn,'pitstop2');
}else{
    die('ERRO AO CONECTAR AO BD');
}

?>