<?php
require('../includes/conexao.php');

$id = $_GET['id'];

$sql = "DELETE FROM cadastro WHERE id = $id";
if(mysqli_query($conn,$sqli)){
    echo "
    <script>
    alert('Deletado com sucesso');
    location.href='../listar-contato.php'

    
    </script>
    
    
    ";
}

?>