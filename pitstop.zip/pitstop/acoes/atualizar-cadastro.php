<?php
require('../includes/conexao.php');

$id = $_POST['id'];
$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$email = $_POST['email'];
$mensagem = $_POST['mensagem'];

$sql = "

UPDATE  cadastro
SET
nome= '$nome'
sobrenome= '$sobrenome'
email= '$email'
mensagem= '$mensagem'
WHERE id= $id";

if(mysqli_query($conn,$sql)){
    echo "
    <script>
    alert ('Dados alterados com sucesso');
    location.href='../listar-contatos.php'
    
    </script>
    
    ";
}

?>
