<?php 
require('../includes/conexao.php');

//SE TEM FORMULÁRIO,FAZ ASSIM
$nome = mb_strtoupper($_POST['nome']);
$sobrenome = mb_strtoupper($_POST['sobrenome']);
$email= $_POST['email'];
$mensagem = mb_strtoupper($_POST['mensagem']);

//SE NÃO TEM FORMULÁRIO, FAZ ASSIM
/*
$nome = "maria";
$email = "maria@maria";
$telefone = 423423423;
$mensagem = "blablablabla";
*/

$sql = "
    INSERT INTO
            cadastro
    (nome, sobrenome, email, mensagem)
        VALUES
    ('$nome', '$sobrenome', '$email', '$mensagem');
";

if(mysqli_query($conn, $sql)){
    echo "
        <script>
            alert('salvo com sucesso');
            location.href='../';
        </script>
    ";
}else{
    echo "
    <script>
        alert('ERRO AO SALVAR ');
        location.href='../';
    </script>
";
}

?>